from flask import Flask, request, render_template
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/courses.html')
def courses():
    return render_template ('courses.html')

@app.route('/about.html')
def about():
    return render_template ('about.html')

@app.route('/signin.html')
def signin():
    return render_template ('signin.html')

@app.route('/contactus.html')
def contactus():
    return render_template ('contactus.html')



if __name__=='__main__':
    app.run(debug=True,port=5102)